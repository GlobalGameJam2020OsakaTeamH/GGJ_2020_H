﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManagerObjectPArentt : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        //! 削除しない
        DontDestroyOnLoad(this);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
