using UnityEngine.Events;

[System.Serializable]
public class UnityEventString : UnityEvent<string>{

}
