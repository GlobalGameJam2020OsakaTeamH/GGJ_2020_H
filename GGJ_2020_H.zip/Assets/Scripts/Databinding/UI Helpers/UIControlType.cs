public enum UIControlType
{
    TMP_InputField,
    TMP_Text,
    TMP_TextMeshProUGUI,
    Legacy_InputField,
    Legacy_Text,
    Invalid
}
