﻿using UnityEngine;
using UnityEditor;

[CustomPropertyDrawer(typeof(Vector3Double))] 
public class Vector3DoubleDrawer: CustomVector3Drawer<double> {
    
}