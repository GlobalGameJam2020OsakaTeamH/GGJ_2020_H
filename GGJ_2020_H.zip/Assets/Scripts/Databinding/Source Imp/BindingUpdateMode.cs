public enum BindingUpdateMode{
    PropertyChangedEvent,
    Manual

}
