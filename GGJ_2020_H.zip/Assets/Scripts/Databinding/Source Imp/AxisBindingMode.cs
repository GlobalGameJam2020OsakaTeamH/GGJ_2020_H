[System.Serializable]
public enum AxisBindingMode{
    WorldSpace,
    LocalSpace,
    LocalSpaceIgnoreScale
}
