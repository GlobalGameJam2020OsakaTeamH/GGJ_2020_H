
[System.Serializable]
public enum Axis{
    X,
    Y,
    Z
}

public enum Axis2D{
    X,
    Y
}
