﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "BuyWeapon", menuName = "Items/BuyWeapon")]
public class BuyWeapon : ItemData
{
    protected override void DoItemAction()
    {
 
    }
}
