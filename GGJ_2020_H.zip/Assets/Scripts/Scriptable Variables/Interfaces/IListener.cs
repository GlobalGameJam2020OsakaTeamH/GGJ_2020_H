public interface IListener
{
    void Notify();
}
