﻿public enum VariableType 
{
    Double,
    Boolean,
    String,
    Integer,
    Float,
    Decimal,
    Vector2,
    Vector3,
    Vector4,
    Vector3Int,
    Vector2Int,
    Unspecified
}
